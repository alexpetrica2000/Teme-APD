#include "mpi.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main (int argc, char *argv[])
{
    int  numtasks, rank, len;
    char hostname[MPI_MAX_PROCESSOR_NAME];
 
    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &numtasks); // citire numar taskuri totale
    MPI_Comm_rank(MPI_COMM_WORLD,&rank); // citire rank proces
 
    
    if (rank == 0) {
        int total = atoi(argv[1]); // stochez nr total de elemente ale vect
        int *vector = malloc(total * sizeof(int)); //vector rezultat
        
        for (int i = 0; i < total; i++)
            vector[i] = i; // initializare cerinta

        int number; 
        FILE* in_file = fopen("cluster0.txt", "r"); // deschidere fisier specific
                                                    // rank0 
        // caz in care nu exista fisier returnez eroare
        if (!in_file) {  
            printf("Nu exista fisierul!\n"); 
            exit(-1); 
        }

        int nrneigh; // variabila nr vecini
        int **map = (int**)calloc(3, sizeof(int*)); // map corespunzator
                                                    // topologiei
        
        fscanf(in_file, "%d", &nrneigh); // citesc din workeri
                                        // are coordonatorul 0
        map[rank] = (int*)calloc(nrneigh, sizeof(int)); // aloc memorie

        // citesc workerii si le transmit ca sunt coordonatorul lor
        for (int i = 0; i < nrneigh; i++) {
            fscanf(in_file, "%d", &number);
            map[rank][i] = number;
            MPI_Send(&rank, 1, 
            MPI_INT, number, 0, MPI_COMM_WORLD);
            printf("M(%d,%d)\n",rank,number);
        }
        // le transmit coordonatorilor 1 si 2
        // cati workeri am si care sunt acestia
        MPI_Status status;
        MPI_Send(&nrneigh, 1, 
            MPI_INT, 1, 0, MPI_COMM_WORLD);
        printf("M(%d,%d)\n",rank,1);
    
        MPI_Send(map[rank], nrneigh, 
            MPI_INT, 1, 1, MPI_COMM_WORLD);
        printf("M(%d,%d)\n",rank,1);

        MPI_Send(&nrneigh, 1, 
            MPI_INT, 2, 0, MPI_COMM_WORLD);
        printf("M(%d,%d)\n",rank,2);

        MPI_Send(map[rank], nrneigh, 
            MPI_INT, 2, 1, MPI_COMM_WORLD);
        printf("M(%d,%d)\n",rank,2);   

        // primesc de la coordonatori 1 si 2 cati workeri au
        // si care sunt acestia, ii trec in mapul topologie
        int *aux;
        int dim1,dim2;
        
        MPI_Recv(&number, 1, MPI_INT,
        MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &status);
        
        aux = malloc(number * sizeof(int));

        MPI_Recv(aux, number, MPI_INT,
        status.MPI_SOURCE, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        map[status.MPI_SOURCE] = aux;

        // cand primesc nu stiu de la cine am primit pentru a modifica
        // dimensiunea
        if (status.MPI_SOURCE == 2)
            dim2 = number;
        else
            dim1 = number;

        MPI_Recv(&number, 1, MPI_INT,
        MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &status);

        aux = malloc(number * sizeof(int));

        MPI_Recv(aux, number, MPI_INT,
        status.MPI_SOURCE, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        map[status.MPI_SOURCE] = aux;

        if (status.MPI_SOURCE == 2)
            dim2 = number;
        else
            dim1 = number;
        // acum stiu sigur ca am aflat topologia, o afisez
        printf("%d -> ",rank);
        for (int i = 0; i < 3; i++) {
            printf("%d:",i);
            int l;
            if (i == 0)
                l = nrneigh;
            if (i == 1)
                l = dim1;
            if (i == 2)
                l = dim2;
            for (int j = 0; j < l; j++) {
                if (j != l - 1)
                    printf("%d,",map[i][j]);
                else
                    printf("%d ",map[i][j]);
            }
        }
        printf("\n");

        // acum pentru fiecare worker al meu
        // trebuie sa ii transmit si acestuia topologia
        for (int i = 0; i < nrneigh; i++) {
            for (int j = 0; j < 3; j++) {
                int l;
                if (j == 0)
                    l = nrneigh;
                if (j == 1)
                    l = dim1;
                if (j == 2)
                    l = dim2;
                MPI_Send(&l, 1, 
                MPI_INT, map[rank][i], j, MPI_COMM_WORLD);
                printf("M(%d,%d)\n",rank,map[rank][i]);
                
                MPI_Send(map[j], l, 
                MPI_INT, map[rank][i], j, MPI_COMM_WORLD);
                printf("M(%d,%d)\n",rank,map[rank][i]);
            }
            
        }
        // citesc cate calcule ar trebui
        // sa execute un worker pentru o distributie egala
        // rest daca nu se imparte egal, surplusul este
        // gestionat de coordonatorul2
        int cap = total / (dim1 + dim2 + nrneigh);
        int rest = total % (dim1 + dim2 + nrneigh);

        // ii trimit fiecarui coordonator partea lui pentru procesare
        for (int i = 0; i < nrneigh; i++) {
            MPI_Send(&cap, 1, 
                MPI_INT, map[rank][i], 4, MPI_COMM_WORLD);
            printf("M(%d,%d)\n",rank,map[rank][i]);

            MPI_Send(vector + i * cap, cap, 
                MPI_INT, map[rank][i], 4, MPI_COMM_WORLD);
                printf("M(%d,%d)\n",rank,map[rank][i]);
        }
        // acum le trimit coordonatorilor 1 si 2 bucatile 
        // lor pentru a fi executate de workerii acestora
        number = dim1 * cap;
        MPI_Send(&number, 1, 
                MPI_INT, 1, 4, MPI_COMM_WORLD);
        printf("M(%d,%d)\n",rank,1);

        MPI_Send(vector + nrneigh * cap, dim1 * cap, 
                MPI_INT, 1, 4, MPI_COMM_WORLD);
        printf("M(%d,%d)\n",rank,1);
        number = dim2 * cap + rest;

        MPI_Send(&number, 1, 
                MPI_INT, 2, 4, MPI_COMM_WORLD);
        printf("M(%d,%d)\n",rank,2);

        MPI_Send(vector + (dim1 + nrneigh) * cap, number, 
                MPI_INT, 2, 4, MPI_COMM_WORLD);
        printf("M(%d,%d)\n",rank,2);
        
        // urmeaza sa primesc raspunsurile de la workerii mei
        // cat si de la ceilalti coordonatori
        for (int i = 0; i < nrneigh; i++) {
            MPI_Recv(vector + i * cap, cap, MPI_INT,
                map[rank][i], 4, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }

        MPI_Recv(vector + nrneigh * cap, dim1 * cap, MPI_INT,
                1, 4, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                
        MPI_Recv(vector + (dim1 + nrneigh) * cap, dim2 * cap + rest, MPI_INT,
                2, 4, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        // primesc rezultatul
        printf("Rezultat: ");
        for (int i = 0; i < total; i++) {
            printf("%d ",vector[i]);
        }
        printf("\n");
    }

    if (rank == 1) {
        int number; 

        FILE* in_file = fopen("cluster1.txt", "r"); 
         
        if (!in_file) {  
            printf("oops, file can't be read\n"); 
            exit(-1); 
        } 

        int nrneigh;
        int **map = (int**)calloc(3, sizeof(int*));
        fscanf(in_file, "%d", &nrneigh);
        map[rank] = (int*)calloc(nrneigh, sizeof(int));

        for (int i = 0; i < nrneigh; i++) {
            fscanf(in_file, "%d", &number);
            map[rank][i] = number;
            MPI_Send(&rank, 1, 
            MPI_INT, number, 0, MPI_COMM_WORLD);
            printf("M(%d,%d)\n",rank,number);
        }
        // le trimit datele cunoscute de mine
        // din topologie coordonatorilor 0 si 2
        MPI_Status status;
        MPI_Send(&nrneigh, 1, 
            MPI_INT, 0, 0, MPI_COMM_WORLD);
        printf("M(%d,%d)\n",rank,0);

        MPI_Send(map[rank], nrneigh, 
            MPI_INT, 0, 1, MPI_COMM_WORLD);
        printf("M(%d,%d)\n",rank,0);

        MPI_Send(&nrneigh, 1, 
            MPI_INT, 2, 0, MPI_COMM_WORLD);
        printf("M(%d,%d)\n",rank,2);

        MPI_Send(map[rank], nrneigh, 
            MPI_INT, 2, 1, MPI_COMM_WORLD);
        printf("M(%d,%d)\n",rank,2);

        int *aux;
        int dim0, dim2;

        //primesc de la coordonatorii 0 si 2 datele lor
        // despre topologie
        MPI_Recv(&number, 1, MPI_INT,
        MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &status);

        aux = malloc(number * sizeof(int));

        MPI_Recv(aux, number, MPI_INT,
        status.MPI_SOURCE, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        map[status.MPI_SOURCE] = aux;

        if (status.MPI_SOURCE == 2)
            dim2 = number;
        else
            dim0 = number;

        MPI_Recv(&number, 1, MPI_INT,
        MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &status);

        aux = malloc(number * sizeof(int));

        MPI_Recv(aux, number, MPI_INT,
        status.MPI_SOURCE, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        map[status.MPI_SOURCE] = aux;

        if (status.MPI_SOURCE == 2)
            dim2 = number;
        else
            dim0 = number;

        // am aflat toata topologia, o afisez
        printf("%d -> ",rank);
        for (int i = 0; i < 3; i++) {
            printf("%d:",i);
            int l;
            if (i == 0)
                l = dim0;
            if (i == 1)
                l = nrneigh;
            if (i == 2)
                l = dim2;
            for (int j = 0; j < l; j++) {
                if (j != l - 1)
                    printf("%d,",map[i][j]);
                else
                    printf("%d ",map[i][j]);
                
            }  
        }
        printf("\n");
        // imi anunt toti workerii de topologie
        for (int i = 0; i < nrneigh; i++) {
            for (int j = 0; j < 3; j++) {
                int l;
                if (j == 0)
                    l = dim0;
                if (j == 1)
                    l = nrneigh;
                if (j == 2)
                    l = dim2;
                MPI_Send(&l, 1, 
                MPI_INT, map[rank][i], j, MPI_COMM_WORLD);
                printf("M(%d,%d)\n",rank,map[rank][i]);
                
                MPI_Send(map[j], l, 
                MPI_INT, map[rank][i], j, MPI_COMM_WORLD);
                printf("M(%d,%d)\n",rank,map[rank][i]);
            }
        }
        // primesc de la coordonator 0 bucata mea ce trebuie
        // procesata de workerii mei
        MPI_Recv(&number, 1, MPI_INT,
        0, 4, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        
        aux = malloc(number * sizeof(int));

        MPI_Recv(aux, number, MPI_INT,
        0, 4, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        int cap = number / nrneigh;
        // distribui bucati din vector in mod egal
        // pentru procesare
        for (int i = 0; i < nrneigh; i++) {
            MPI_Send(&cap, 1, 
                MPI_INT, map[rank][i], 4, MPI_COMM_WORLD);
            printf("M(%d,%d)\n",rank,map[rank][i]);

            MPI_Send(aux + i * cap, cap, 
                MPI_INT, map[rank][i], 4, MPI_COMM_WORLD);
            printf("M(%d,%d)\n",rank,map[rank][i]);
        }
        // primesc datele procesate si le trimit 
        // mai departe catre coordonator 0 
        for (int i = 0; i < nrneigh; i++) {
            MPI_Recv(aux + i * cap, cap, MPI_INT,
                map[rank][i], 4, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }

        MPI_Send(aux, nrneigh* cap, 
                MPI_INT, 0, 4, MPI_COMM_WORLD);
        printf("M(%d,%d)\n",rank,0);
    }
    
    // rank2 este identic cu rank1 doar ca oriunde in 
    // rank1 aveam indice 2 acum am 0 
    if (rank == 2) {
        int number; 
        FILE* in_file = fopen("cluster2.txt", "r"); 
         
        if (!in_file) {  
            printf("oops, file can't be read\n"); 
            exit(-1); 
        } 
        int nrneigh;
        int **map = (int**)calloc(3, sizeof(int*));
        fscanf(in_file, "%d", &nrneigh);
        map[rank] = (int*)calloc(nrneigh + 2, sizeof(int));

        for (int i = 0; i < nrneigh; i++) {
            fscanf(in_file, "%d", &number);
            map[rank][i] = number;
            MPI_Send(&rank, 1, 
            MPI_INT, number, 0, MPI_COMM_WORLD);
            printf("M(%d,%d)\n",rank,number);
        }  
        
        MPI_Status status;
        MPI_Send(&nrneigh, 1, 
            MPI_INT, 0, 0, MPI_COMM_WORLD);
            printf("M(%d,%d)\n",rank,0);


        MPI_Send(map[rank], nrneigh, 
            MPI_INT, 0, 1, MPI_COMM_WORLD);
            printf("M(%d,%d)\n",rank,0);


        MPI_Send(&nrneigh, 1, 
            MPI_INT, 1, 0, MPI_COMM_WORLD);
            printf("M(%d,%d)\n",rank,1);


        MPI_Send(map[rank], nrneigh, 
            MPI_INT, 1, 1, MPI_COMM_WORLD);
            printf("M(%d,%d)\n",rank,1);


        int *aux;
        int dim1, dim0;
        MPI_Recv(&number, 1, MPI_INT,
        MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &status);
      
        aux = malloc(number * sizeof(int));

        MPI_Recv(aux, number, MPI_INT,
        status.MPI_SOURCE, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        map[status.MPI_SOURCE] = aux;

        if (status.MPI_SOURCE == 0)
            dim0 = number;
        else
            dim1 = number;
        
        MPI_Recv(&number, 1, MPI_INT,
        MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &status);
        
        aux = malloc(number * sizeof(int));

        MPI_Recv(aux, number, MPI_INT,
        status.MPI_SOURCE, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        map[status.MPI_SOURCE] = aux;

        if (status.MPI_SOURCE == 0)
            dim0 = number;
        else
            dim1 = number;

        printf("%d -> ",rank);
        for (int i = 0; i < 3; i++) {
            printf("%d:",i);
            int l;
            if (i == 0)
                l = dim0;
            if (i == 1)
                l = dim1;
            if (i == 2)
                l = nrneigh;
            for (int j = 0; j < l; j++) {
                if (j != l - 1)
                    printf("%d,",map[i][j]);
                else
                    printf("%d ",map[i][j]);
            }
        }
        printf("\n");

        for (int i = 0; i < nrneigh; i++) {
            for (int j = 0; j < 3; j++) {
                int l;
                if (j == 0)
                    l = dim0;
                if (j == 1)
                    l = dim1;
                if (j == 2)
                    l = nrneigh;
                MPI_Send(&l, 1, 
                MPI_INT, map[rank][i], j, MPI_COMM_WORLD);
                printf("M(%d,%d)\n",rank,map[rank][i]);

                MPI_Send(map[j], l, 
                MPI_INT, map[rank][i], j, MPI_COMM_WORLD);
                printf("M(%d,%d)\n",rank,map[rank][i]);
            }  
        }
        
        MPI_Recv(&number, 1, MPI_INT,
        0, 4, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        aux = malloc(number * sizeof(int));
 
        MPI_Recv(aux, number, MPI_INT,
        0, 4, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        // singura diferenta este ca coordonatorul2
        // gestioneaza restul impartirii egale catre workeri
        // pe scurt un worker va avea max nrworkeri - 1 
        // operatii in plus
        int cap = number / nrneigh;
        int rest = number % nrneigh;
        
        for (int i = 0; i < nrneigh; i++) {
            if (i != nrneigh - 1) {
                MPI_Send(&cap, 1, 
                    MPI_INT, map[rank][i], 4, MPI_COMM_WORLD);
                printf("M(%d,%d)\n",rank,map[rank][i]);

                MPI_Send(aux + i * cap, cap, 
                    MPI_INT, map[rank][i], 4, MPI_COMM_WORLD);
                printf("M(%d,%d)\n",rank,map[rank][i]);
            }
            else {
                number = cap + rest;
                MPI_Send(&number, 1, 
                    MPI_INT, map[rank][i], 4, MPI_COMM_WORLD);
                printf("M(%d,%d)\n",rank,map[rank][i]);

                MPI_Send(aux + i * cap, number, 
                    MPI_INT, map[rank][i], 4, MPI_COMM_WORLD);
                printf("M(%d,%d)\n",rank,map[rank][i]);
            }
        }
          
        for (int i = 0; i < nrneigh; i++) {
            if (i != nrneigh - 1)
            MPI_Recv(aux + i * cap, cap, MPI_INT,
                map[rank][i], 4, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            else 
            MPI_Recv(aux + i * cap, cap + rest, MPI_INT,
                map[rank][i], 4, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }
        MPI_Send(aux, nrneigh* cap + rest, 
                MPI_INT, 0, 4, MPI_COMM_WORLD);
        printf("M(%d,%d)\n",rank,0);
    }

    if (rank != 0 && rank != 1 && rank != 2) {

        int parent;
        // sunt worker, salvez cine este coordonatorul
        // de care apartin
        MPI_Recv(&parent, 1, MPI_INT,
        MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        int number, dim0, dim1, dim2;
        int *aux;
        MPI_Status status;
        // dim0 dim1 dim2 nr workeri pt
        // fiecare coordonator, folosit pentru topologie
        int **map = (int**)calloc(3, sizeof(int*));
        
        // primesc topologia de la coordonator
        for (int i = 0; i < 3; i++) {
            MPI_Recv(&number, 1, MPI_INT,
            parent, i, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

            aux = malloc(number * sizeof(int));
            MPI_Recv(aux, number, MPI_INT,
            parent, i, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

            map[i] = aux;

            if (i == 0) dim0 = number;
            if (i == 1) dim1 = number;
            if (i == 2) dim2 = number;
        }
        // o afisez
        printf("%d -> ",rank);
        for (int i = 0; i < 3; i++) {
            printf("%d:",i);
            int l;
            if (i == 0)
                l = dim0;
            if (i == 1)
                l = dim1;
            if (i == 2)
                l = dim2;
            for (int j = 0; j < l; j++) {
                if (j != l - 1)
                    printf("%d,",map[i][j]);
                else
                    printf("%d ",map[i][j]);
            } 
        }
        printf("\n");
        // primesc bucata mea de vector ce trebuie procesata
        MPI_Recv(&number, 1, MPI_INT,
            parent, 4, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        aux = malloc(number * sizeof(int));
        
        MPI_Recv(aux, number, MPI_INT,
            parent, 4, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        // fac procesarea
        for (int i = 0; i < number; i++) {
            aux[i] *= 2;
        }
        // trimit coordonatorului bucata de vector modificata
        MPI_Send(aux, number, 
                MPI_INT, parent, 4, MPI_COMM_WORLD);
        printf("M(%d,%d)\n",rank,parent);
    }
    MPI_Finalize();
}