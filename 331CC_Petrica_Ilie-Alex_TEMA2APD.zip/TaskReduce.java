
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicInteger;

public class TaskReduce implements Runnable{
    String name;
    ArrayList<ResultMap> partialResult;
    ExecutorService tpe;
    AtomicInteger inQueue;

    public TaskReduce(String name, ExecutorService tpe, AtomicInteger inQueue, ArrayList<ResultMap> partialResult) {
        this.name = name;
        this.tpe = tpe;
        this.inQueue = inQueue;
        this.partialResult = partialResult;
    }
    // varianta rapida a sirului lui Fibonacci
    public Integer fibo(int poz) {
        double phi = (1 + Math.sqrt(5)) / 2;
        return (int) Math.round(Math.pow(phi, poz) / Math.sqrt(5));
    }
    @Override
    public void run() {
        // creez obiect ResultReduce specific pt lista finala
        ResultReduce rez = new ResultReduce();
        double rang = 0;
        String maxword = "";
        int countmax = 0;
        int totwords = 0;
        HashMap<Integer,Integer> finalMap = new HashMap<>();
        // etapa de combinare
        // generez dictionarul final, numarul total de cuvinte si lungime cuvantului de dimensiune maxima
        // din fisierul respectiv
        for (ResultMap partial : partialResult) {
                for (String word : partial.getMax()) {
                    if (word.length() - maxword.length() > 0)
                        maxword = word;
                }
                for (HashMap.Entry<Integer,Integer> entry: partial.getDictionaryOfWords().entrySet()) {
                    if (finalMap.containsKey(entry.getKey())) {
                        finalMap.put(entry.getKey(), finalMap.get(entry.getKey()) + entry.getValue());
                    } else {
                        finalMap.put(entry.getKey(), entry.getValue());
                    }
                    totwords += entry.getValue();
                }

        }
        // etapa de procesare
        // calculez cate cuvinte au lungimea cuvantului maxim + rangul fisierului
        for (HashMap.Entry<Integer,Integer> entry: finalMap.entrySet()) {
            rang +=  fibo(entry.getKey() + 1)*entry.getValue() / (double)totwords;

            if (entry.getKey() == maxword.length())
                countmax += entry.getValue();
        }
        // le setez catre obiect ce va ajunge in final result
        rez.setMaxlen(maxword.length());
        rez.setName(name);
        rez.setWordsmaxlen(countmax);
        rez.setRang(rang);

        // am nevoie de semafor pentru scriere deoarece folosesc add (am zis sa fac ceva diferit
        // fata de TaskMap, sa nu mai trimit id) si toti workerii ar putea da add in acelasi timp
        // nu as avea garantia ca finalresult o sa aiba sizeulf final nrdocumtente (deci ca toti au scris
        // corect)
        try {
            Tema2.write.acquire();
            Tema2.finalResult.add(rez);
            Tema2.write.release();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        // cand raman fara taskuri opresc workerul
        int left = inQueue.decrementAndGet();
        if (left == 0) {
            tpe.shutdown();
        }
    }
}


