import java.util.ArrayList;
import java.util.HashMap;

public class ResultMap {
    private String name;
    private HashMap<Integer, Integer> dictionaryOfWords;
    private ArrayList<String> maxWords;

    public ResultMap() {
        dictionaryOfWords = new HashMap<>();
        maxWords = new ArrayList<>();
        name = "";
    }

    // metoda de add in hashmap, daca keya exista atunci maresc valoarea
    // cu 1, am mai gasit un cuvant cu aceasta lungime, altfel adaug
    // in hasmap cu key si val 1
    public void add(Integer key) {
        if (dictionaryOfWords.containsKey(key)) {
            dictionaryOfWords.put(key, dictionaryOfWords.get(key) + 1);
        }
        else
            dictionaryOfWords.put(key,1);
    }

    // pentru valoare maxima daca nu am elemente in vector
    // am gasit maximul, altfel daca stringul trimis ca parametru este
    // mai lung resetez lista si adaug noul string
    // pentru aceeiasi lungime doar adaug in lista
    public void max(String string) {
        if (maxWords.size() == 0) {
            maxWords.add(string);
            return;
        }
        if (maxWords.get(0).length() - string.length() < 0){
            maxWords = new ArrayList<>();
            maxWords.add(string);
            return;
        }
        if (maxWords.get(0).length() - string.length() == 0){
            maxWords.add(string);
        }

    }
    public void setName(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }
    public ArrayList<String> getMax() {
        return maxWords;
    }

    public HashMap<Integer,Integer> getDictionaryOfWords(){
        return dictionaryOfWords;
    }

    public String toString() {
        return name + " " + dictionaryOfWords + "; (\"" + maxWords + "\")";
    }


}
