public class Map {

    public final String name;
    public final int offset;
    public final long size;

    public Map(String name, int offset, long size) {
        this.name = name;
        this.offset = offset;
        this.size = size;
    }

    public String toString() {
        return name + " " + offset + " " + size;
    }

}
