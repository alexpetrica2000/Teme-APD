import java.awt.image.AreaAveragingScaleFilter;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class Tema2 {

    static ArrayList<ResultMap> partialResult = new ArrayList<>(); // lista distribuita intre workeri pt rez partiale
    static ArrayList<ResultReduce> finalResult = new ArrayList<>(); // lista distribuita intre workeri pt rez finale
    static Semaphore write; // semafor pentru scriere in final result, distribuita intre workeri

    public static void main(String[] args) throws IOException, InterruptedException {

        if (args.length < 3) {
            System.err.println("Usage: Tema2 <workers> <in_file> <out_file>");
            return;
        }

        // efectuare citiri de la input
        int nrworkers;
        nrworkers = Integer.parseInt(args[0]);
        String filein = args[1];
        String fileout = args[2];
        write = new Semaphore(1);
        File obj = new File(filein);
        Scanner myReader = new Scanner(obj);

        long dim_fragment = Integer.parseInt(myReader.next());
        int nr_documente = Integer.parseInt(myReader.next());

        // hashmap asociat nume_document - index din document de intrare
        // vector String pentru numele documentelor si array de tip Map
        HashMap<String, Integer>indexes = new HashMap<>();
        String []files = new String[nr_documente];
        ArrayList<Map> tasks = new ArrayList<>();

        for (int i = 0; i < nr_documente; i++) {
            files[i] = myReader.next();
            indexes.put(files[i], i);
        }

         for (int i = 0; i < nr_documente; i++) {
             Path path = Paths.get(files[i]);
            long length = Files.size(path);
            int offset = 0;

            // se creaza taskurile de tip map, length este dimensiunea fisierului in bytes
             // dupa care o sa calculam dimensiunea fragmentului de citit in map
            while (length != 0) {
                if (dim_fragment < length) {
                    tasks.add(new Map(files[i], offset, dim_fragment));
                    offset += dim_fragment;
                    length -= dim_fragment;
                }
                else {
                    tasks.add(new Map(files[i], offset, length));
                    length = 0;
                }
            }

        }
        // pornim workerii pentru etapa de TaskMap
        // inQueue este de marimea numarului de taskuri
        // porners nrworkers workeri
        ExecutorService tpe = Executors.newFixedThreadPool(nrworkers);
        AtomicInteger inQueue = new AtomicInteger(tasks.size());
        for (int i = 0; i < tasks.size(); i ++) {
            partialResult.add(new ResultMap());
            tpe.submit(new TaskMap(i,tasks.get(i),tpe,inQueue));
        }
        // astept sa termine workerii treaba (ma asigur ca threadul coordonator nu o ia in fata)
        tpe.awaitTermination(1000, TimeUnit.MILLISECONDS);


        // generez noii workeri dar acum inQueue este de dimensiunea
        // numarului de documente (atat se aloca pt op reduce)
        tpe = Executors.newFixedThreadPool(nrworkers);
        inQueue = new AtomicInteger(nr_documente);
        // fiecare TaskReduce are nevoie de nume document
        // cat si lista de rezultatePartiale obtinute de map
        // pt acel document
        for (int i = 0; i < nr_documente; i++) {
            ArrayList<ResultMap> list = new ArrayList<>();
            for (ResultMap elem : partialResult)
                if (elem.getName().compareTo(files[i]) == 0)
                    list.add(elem);
            tpe.submit(new TaskReduce(files[i], tpe, inQueue, list));
        }
        tpe.awaitTermination(1000, TimeUnit.MILLISECONDS);


        // dupa ce am obtinut rezultatele ele trebuiesc sortate
        // Descrescator dupa rang iar apoi crescator indexul
        // la care se afla in documentul input
        Collections.sort(finalResult, new Comparator<ResultReduce>() {
            @Override
            public int compare(ResultReduce o1, ResultReduce o2) {
                double compare = o1.getRang() - o2.getRang();
                if (compare > 0)
                    return -1;
                else if (compare < 0)
                        return 1;
                    else {
                        return indexes.get(o1.getName()) - indexes.get(o2.getName());
                }

            }
        });
        // scriem in fisierul de iesire
        FileWriter myWriter = new FileWriter(fileout);
        for (ResultReduce rr : finalResult)
            myWriter.write(rr.toString());
        myWriter.close();
    }
}
