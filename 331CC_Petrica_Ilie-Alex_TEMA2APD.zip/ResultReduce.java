import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.StringTokenizer;

public class ResultReduce {

    private String name;
    private double rang;
    private int maxlen;
    private int wordsmaxlen;

    public String getName() {
        return name;
    }

    public double getRang() {
        return rang;
    }

    public int getMaxlen() {
        return maxlen;
    }

    public int getWordsmaxlen() {
        return wordsmaxlen;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setRang(double rang) {
        this.rang = rang;
    }

    public void setMaxlen(int maxlen) {
        this.maxlen = maxlen;
    }

    public void setWordsmaxlen(int wordsmaxlen) {
        this.wordsmaxlen = wordsmaxlen;
    }

    public String toString() {
        BigDecimal bd = new BigDecimal(rang).setScale(2, RoundingMode.HALF_UP);
        rang = bd.doubleValue();
        StringTokenizer st = new StringTokenizer(name,"/");

        while(st.hasMoreTokens()) {
            name = st.nextToken();
        }
        return name + "," + rang + "," + maxlen + "," + wordsmaxlen + '\n';
    }
}
