import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.StringTokenizer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicInteger;

public class TaskMap implements Runnable {
    int id;
    Map map;
    ExecutorService tpe;
    AtomicInteger inQueue;

    public TaskMap(int id, Map map, ExecutorService tpe, AtomicInteger inQueue) {
        this.id = id;
        this.map = map;
        this.tpe = tpe;
        this.inQueue = inQueue;
    }


    @Override
    public void run() {
        ResultMap rez = new ResultMap();
        try {
            // ma pozitionez in fisier la offset prin random acces file
            // cunosc lungimea fisierului
            RandomAccessFile file = new RandomAccessFile(map.name, "r");
            file.seek(map.offset);
            StringBuilder s = new StringBuilder();
            long length = file.length();

            // citesc primul caracter, variabila
            // ignore first imi spune daca trebuie sa ignor primul
            // cuvant citit cand voi sparge dupa separatori
            char c = (char) file.readByte();
            s.append(c);
            boolean ignorefirst = false;

            // practic dupa ce am citit primul caracter verific daca acesta
            // nu este separator si daca nu este separator il citesc pe cel anterior
            // daca cel anterior nu este separator atungi trebuie ignorat primul cuvant
            if (isOk(c)) {
                if (map.offset - 1 > 0) {
                    file.seek(map.offset - 1);
                    c = (char) file.readByte();
                    if (isOk(c))
                        ignorefirst = true;
                }
            }

            // citesc cuvantul dintre offset si offset + 1 + size (ce mai aveam pt bucata mea)
             file.seek(map.offset + 1);
            for (int i = map.offset + 1; i < map.offset + map.size; i++)
                s.append((char) file.readByte());

            // counter inseamna unde ma aflu in fisier practic
            long counter = map.offset + map.size;
            c = s.charAt(s.length()-1);
            // in c am ultimul caracter citit, daca nu este separator
            // citesc pana cand dau de un separator sau de sfarsitul
            // fisierului
            if (isOk(c)){
                while(counter < length){
                    c = (char) file.readByte();
                    if (isOk(c))
                        s.append(c);
                    else
                        break;
                    counter++;
                }
            }
            // separ cuvintele intre delimitatori
            // si formez obiectul ResultMap
            // ce in final este adaugat in main (unde este o lista
            // distribuita pentru toate threadurile)
            StringTokenizer st = new StringTokenizer(s.toString(), ";:/?~\\.,><`[]{}()!@#$%^&-_+'=*\"| \t\r\n");

            while (st.hasMoreTokens()) {
                if (ignorefirst) {
                    st.nextToken();
                    ignorefirst = false;
                    continue;
                }
                String aux = st.nextToken();
                rez.add(aux.length());
                rez.max(aux);
            }
            rez.setName(map.name);
            Tema2.partialResult.set(id,rez);
        } catch (IOException e) {
            e.printStackTrace();
        }
        // daca left ajunge pe 0 inseamna ca nu mai sunt taskuri de efectuat deci opresc workerul
        int left = inQueue.decrementAndGet();
        if (left == 0) {
            tpe.shutdown();
        }
    }
    // functie ce verifica daca un caracter este separator sau valid
    public boolean isOk(char c) {
        String separators = ";:/?~\\.,><`[]{}()!@#$%^&-_+'=*\"| \t\r\n";
        for (int i = 0; i < separators.length(); i++) {
            if (c == separators.charAt(i))
                return false;
        }
        return true;
    }

}
