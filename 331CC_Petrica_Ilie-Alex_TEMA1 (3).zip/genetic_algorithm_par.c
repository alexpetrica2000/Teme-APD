#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "genetic_algorithm_par.h"
struct my_arg {
	int id;
	int P;
	int object_count;
    int sack_capacity;
    int generations_count;
    const sack_object *objects;
    individual **current_generation;
    individual **next_generation;
    pthread_barrier_t *barrier;
	
};

int read_input(sack_object **objects, int *object_count, int *sack_capacity, int *generations_count, int *P, int argc, char *argv[])
{
	FILE *fp;

	if (argc < 4) {
		fprintf(stderr, "Usage:\n\t./tema1 in_file generations_count\n");
		return 0;
	}

	fp = fopen(argv[1], "r");
	if (fp == NULL) {
		return 0;
	}

	if (fscanf(fp, "%d %d", object_count, sack_capacity) < 2) {
		fclose(fp);
		return 0;
	}

	if (*object_count % 10) {
		fclose(fp);
		return 0;
	}

	sack_object *tmp_objects = (sack_object *) calloc(*object_count, sizeof(sack_object));

	for (int i = 0; i < *object_count; ++i) {
		if (fscanf(fp, "%d %d", &tmp_objects[i].profit, &tmp_objects[i].weight) < 2) {
			free(objects);
			fclose(fp);
			return 0;
		}
	}

	fclose(fp);

	*generations_count = (int) strtol(argv[2], NULL, 10);
	
	if (*generations_count == 0) {
		free(tmp_objects);

		return 0;
	}

	*objects = tmp_objects;

    *P = (int) strtol(argv[3], NULL, 10);

	return 1;
}

void print_best_fitness(const individual *generation)
{
	printf("%d\n", generation[0].fitness);
}

// compute_fitness paralel
void compute_fitness_function(const sack_object *objects, individual *generation, int object_count, int sack_capacity, int start, int stop)
{
	int weight;
	int profit;

	for (int i = start; i < stop; ++i) {
		weight = 0;
		profit = 0;

		for (int j = 0; j < generation[i].chromosome_length; ++j) {
			if (generation[i].chromosomes[j]) {
				weight += objects[j].weight;
				profit += objects[j].profit;
			}
		}

		generation[i].fitness = (weight <= sack_capacity) ? profit : 0;
	}
}

// functia de comparare utilizata de Qsort, scalata folosind retinerea numarului de biti
// de 1 in structura individual
int cmpfunc(const void *a, const void *b)
{
	individual *first = (individual *) a;
	individual *second = (individual *) b;

	return second->fitness - first->fitness != 0 ? 
				second->fitness - first->fitness  : first->nrones - second->nrones != 0 ? 
					first->nrones - second->nrones : (second->index - first->index);

}
// functia 1 de mutatie asemanatoare codului secvential
// cu observatia ca se modifica numarul de 1 de biti din individual
void mutate_bit_string_1(individual *ind, int generation_index)
{
	int i, mutation_size;
	int step = 1 + generation_index % (ind->chromosome_length - 2);

	if (ind->index % 2 == 0) {
		mutation_size = ind->chromosome_length * 4 / 10;
		for (i = 0; i < mutation_size; i += step) {
			ind->chromosomes[i] = 1 - ind->chromosomes[i];
			ind->chromosomes[i] == 0 ? ind->nrones-- : ind->nrones++;
		}
	} else {
		mutation_size = ind->chromosome_length * 8 / 10;
		for (i = ind->chromosome_length - mutation_size; i < ind->chromosome_length; i += step) {
			ind->chromosomes[i] = 1 - ind->chromosomes[i];
			ind->chromosomes[i] == 0 ? ind->nrones-- : ind->nrones++;
		}
	}
}
// functia 2 de mutatie, identica codului secvential
// cu observatia ca se modifica numarul de biti de 1 din individual
void mutate_bit_string_2(individual *ind, int generation_index)
{
	int step = 1 + generation_index % (ind->chromosome_length - 2);

	for (int i = 0; i < ind->chromosome_length; i += step) {
		ind->chromosomes[i] = 1 - ind->chromosomes[i];
		ind->chromosomes[i] == 0 ? ind->nrones-- : ind->nrones++;
	}
}
// am schimbat memcpyul cu un for clasic pentru a calcula
// numarul de biti de 1 din copil
void crossover(individual *parent1, individual *child1, int generation_index)
{
	individual *parent2 = parent1 + 1;
	individual *child2 = child1 + 1;
	int count = 1 + generation_index % parent1->chromosome_length;
	child1->nrones = 0;
	child2->nrones = 0;
	for (int i = 0; i < count; i++) {
		child1->chromosomes[i] = parent1->chromosomes[i] ;
		if (parent1->chromosomes[i])
			child1->nrones++;
	}
	for (int i = count; i < parent1->chromosome_length; i++) {
		child1->chromosomes[i]  = parent2->chromosomes[i] ;
		if (parent2->chromosomes[i])
			child1->nrones++;
	}

	for (int i = 0; i < count; i++) {
		child2->chromosomes[i]  = parent2->chromosomes[i] ;
		if (parent2->chromosomes[i])
			child2->nrones++;
	}
	for (int i = count; i < parent1->chromosome_length; i++) {
		child2->chromosomes[i]  = parent1->chromosomes [i] ;
		if (parent1->chromosomes[i])
			child2->nrones++;
	}

}

// identica codului serial cu mentiunea 
// actualizarii numarul de biti de 1
void copy_individual(individual *from, individual *to)
{	
	memcpy(to->chromosomes, from->chromosomes, from->chromosome_length * sizeof(int));
	to->nrones = from->nrones;
}

// free paralel
void free_generation(individual *generation, int start, int stop)
{
	int i;

	for (i = start; i < stop; ++i) {
		free(generation[i].chromosomes);
		generation[i].chromosomes = NULL;
		generation[i].fitness = 0;
	}
}

void run_genetic_algorithm(const sack_object *objects, int object_count, int generations_count, int sack_capacity, int P)
{
	
	individual *current_generation = (individual*) calloc(object_count, sizeof(individual));
	individual *next_generation = (individual*) calloc(object_count, sizeof(individual));
    pthread_barrier_t barrier;

    pthread_t tid[P];
	pthread_barrier_init(&barrier, NULL, P);
    struct my_arg *arguments;
    arguments = (struct my_arg*) malloc(P * sizeof(struct my_arg));


	for (int i = 0; i < object_count; ++i) {
		current_generation[i].fitness = 0;
		current_generation[i].chromosomes = (int*) calloc(object_count, sizeof(int));
		current_generation[i].chromosomes[i] = 1;
		current_generation[i].index = i;
		current_generation[i].chromosome_length = object_count;
		current_generation[i].nrones = 1;

		next_generation[i].fitness = 0;
		next_generation[i].chromosomes = (int*) calloc(object_count, sizeof(int));
		next_generation[i].index = i;
		next_generation[i].chromosome_length = object_count;
	}

	// construiesc argumentul functiei thread (strucutra ce contine datele
	// necesare pentru procesare)
	// creez threadurrile
    for (int i = 0; i < P; i++) {
		arguments[i].id = i;
        arguments[i].P = P;
        arguments[i].object_count = object_count;
        arguments[i].generations_count = generations_count;
        arguments[i].objects = objects;
        arguments[i].current_generation = &current_generation;
        arguments[i].next_generation = &next_generation;
        arguments[i].barrier = &barrier;
        arguments[i].sack_capacity = sack_capacity;

		pthread_create(&tid[i], NULL, thread_function, &arguments[i]);
	}

    for (int i = 0; i < P; i++) {
		pthread_join(tid[i], NULL);
	}
    pthread_barrier_destroy(&barrier);
}

int min(const int a, const int b) {
	return a > b? b : a;
}

void *thread_function(void *arg)
{
	struct my_arg* data = (struct my_arg*) arg;
   
	int cursor;
	int count;
	int start;
    int stop;
	
	// for pana la generatii + 1, deoarece codul serial
	// executa generations_count + 1 compute fitness + qsort
    for (int k = 0; k < data->generations_count + 1; k++) {
		
		// initializare indexi de start stop folositi de threaduri + cursor
		// fiecare thread are propria variabila de count + coursor
		start = data->id * (double) data->object_count / data->P;
		stop = min((data->id + 1) * (double)data->object_count / data->P, data->object_count);
		cursor = 0;
		
		// folosim prima bariera pentru a ne asigura ca threadul cu id 0 a facut sortul 
		// la operatia anterioara (pentru a ne asigura ca facem compute fitness pe data corecte)
		// a 2a bariera este folosita pentru a asigura qsortul ca toate threadurile si-au facut
		// compute fitnessul
		pthread_barrier_wait(data->barrier);
		compute_fitness_function(data->objects, *data->current_generation, data->object_count, data->sack_capacity, start, stop);
		pthread_barrier_wait(data->barrier);

        if (data->id == 0)
            qsort(*data->current_generation, data->object_count, sizeof(individual), cmpfunc);

		// daca k este generations count am facut compute fitness si qsort de generations count + 1 ori
		// iar celelate operatii in generations count ori, deci am terminat de procesat
		if (k == data->generations_count)
			break;
		pthread_barrier_wait(data->barrier);

		// setam indexii de start si stop pentru a paraleliza bucata de 30 %
		// folosita de copy_individual
		count = data->object_count * 3 / 10;
		start = data->id * (double) count / data->P;
    	stop = min((data->id + 1) * (double) count / data->P, count);

		for (int i = start; i < stop; ++i) {
			copy_individual(*data->current_generation + i, *data->next_generation + i);
		}
		
		cursor = count;
		count = data->object_count  * 2 / 10;

		//setam indexii de start si stop pentru a paraleliza acum 
		// operatiile de copy individual si mutate_bit_string 1 si 2.
		// practic le pot face in acelasi for, ele se ocupa de bucati
		// separate raportate la acelasi index. Fiecare thread 
		// ia o bucata din primii 20% si din urmatorii 20 % 
		// (de aceea adun data->object_count  * 2 / 10)
		start = data->id * (double) count / data->P;
    	stop = min((data->id + 1) * (double) count / data->P, count);
		for (int i = start; i < stop; ++i) {
			copy_individual(*data->current_generation + i, *data->next_generation + cursor + i);
			copy_individual(*data->current_generation + i + count, *data->next_generation + cursor + data->object_count  * 2 / 10 + i);
			mutate_bit_string_1(*data->next_generation + cursor + i, k);
			mutate_bit_string_2(*data->next_generation + cursor + data->object_count  * 2 / 10 + i, k);
		}
		count = data->object_count  * 3 / 10;
		cursor += 2 * data->object_count / 10 + 2 * data->object_count / 10;

		if (count % 2 == 1) {
			copy_individual(*data->current_generation + data->object_count - 1, *data->next_generation + cursor + count - 1);
			count--;
		}
		start = data->id * (double) count / data->P;
    	stop = min((data->id + 1) * (double) count / data->P, count);
		
		// as avea o problema la indexul de start daca ar fi impar
		// s-ar suprapune cu stopul anterior (as face crossover
		// din nou in aceeiasi zona)
		if (start % 2 == 1)
			start++;
		for (int i = start; i < stop; i += 2) {
			crossover(*data->current_generation + i, *data->next_generation + cursor + i, k);
		}
		// pun bariera pentru a ma asigura ca toate operatiile au fost procesate de toate
		// threadurile (crossover, mutate_bit_string1/2, copy_individual)
		// astfel pot face schimbul de generatii (paralelizat si acesta)
		pthread_barrier_wait(data->barrier);
		start = data->id * (double) data->object_count / data->P;
    	stop = min((data->id + 1) * (double)data->object_count / data->P, data->object_count);

		// schimbul de generatii paralelizat, copiez (stop-start) * sizeof(indiviual) bytes
		// incepand de la start (ma asigur ca fiecare thread muta doar bucatile repartizate acestuia)
		individual *tmp = (individual*) calloc(data->object_count, sizeof(individual)); ;
		memmove(tmp, *data->current_generation + start, (stop - start) * sizeof(individual));
		memmove(*data->current_generation + start, *data->next_generation + start, (stop - start) * sizeof(individual));
		memmove(*data->next_generation + start, tmp, (stop - start)* sizeof(individual));

		pthread_barrier_wait(data->barrier);

		
		for (int i = start; i < stop; ++i) {
			(*data->current_generation)[i].index = i;
		}
		if (data->id == 0)
			if (k % 5 == 0) {
				print_best_fitness(*data->current_generation);
			}
    }
	if (data->id == 0) {
		print_best_fitness(*data->current_generation);
	}
	// prima bariera pentru a ma asigura ca toate threadurile si-au terminat procesarile
	// acum pot da free continutului generatiilor(fiecarui individuals), acesta paralelizat
	// a doua bariera este folosita sa ma asigura ca procesarea operatiilor de free
	// s-au terminat, pot pune un thread sa dea free si generatiilor (doar un singur
	// thread trebuie sa faca asta, toate threadurile au referinta catre aceasta)
	pthread_barrier_wait(data->barrier);
	free_generation(*data->current_generation, start, stop);
	free_generation(*data->next_generation, start, stop);
	pthread_barrier_wait(data->barrier);
	
	if (data->id == 0) {
		free(*data->current_generation);
		free(*data->next_generation);
	}
	pthread_exit(NULL);
}